package com.boot.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.boot.dto.*;

public interface DefactService {
	public void insertDefect(Defect_ReportsDTO defect_ReportsDTO);
//	public void insertcarDefect(Defect_ReportsDTO defect_ReportsDTO);
}
